
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QByteArray>
#include <vector>
#include "VoleMachine.h"

class QLabel;
class QTableWidget;
class QTextEdit;
class QPushButton;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);

private slots:
    void loadProgram();
    void stepProgram();
    void runProgram();
    void resetProgram();

private:
    void buildUi();
    void refreshUi(const QString &message = QString());
    void appendLog(const QString &message);
    QString hexByte(unsigned char value) const;

    VoleMachine machine;
    QString loadedPath;
    int startAddress = 0;
    bool programLoaded = false;

    QLabel *fileLabel = nullptr;
    QLabel *pcLabel = nullptr;
    QLabel *irLabel = nullptr;
    QLabel *statusLabel = nullptr;
    QTableWidget *registerTable = nullptr;
    QTableWidget *memoryTable = nullptr;
    QTextEdit *screenOutput = nullptr;
    QTextEdit *logOutput = nullptr;
    QPushButton *stepButton = nullptr;
    QPushButton *runButton = nullptr;
    QPushButton *resetButton = nullptr;
};

#endif
