#include "VoleMachine.h"
#include "ProgramLoader.h"
#include <vector>
void VoleMachine::reset() {
    memory.reset();
    registers.reset();
    display.clearScreen();
    cpu.reset();
}
bool VoleMachine::loadProgram(const std::string& path, std::string& error, int startAddress) {
    ProgramLoader loader;
    std::vector<unsigned char> bytes;
    if (!loader.load(path, bytes, error, startAddress)) return false;
    reset();
    cpu.reset(startAddress);
    for (std::size_t i = 0; i < bytes.size(); ++i)
        memory.write(startAddress + static_cast<int>(i), bytes[i]);
    return true;
}
void VoleMachine::run() { cpu.execute(memory, registers, display); }
StepResult VoleMachine::step() { return cpu.step(memory, registers, display); }
void VoleMachine::showScreen() const { display.show(); }

MachineSnapshot VoleMachine::snapshot() const {
    MachineSnapshot state;
    state.programCounter = cpu.getProgramCounter();
    state.instructionRegister = cpu.getInstructionRegister();
    state.registers = registers.snapshot();
    state.memory = memory.snapshot();
    state.screenOutput = display.values();
    state.halted = cpu.isHalted();
    return state;
}
