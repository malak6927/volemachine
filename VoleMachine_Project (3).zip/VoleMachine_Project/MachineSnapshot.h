#ifndef MACHINESNAPSHOT_H
#define MACHINESNAPSHOT_H
#include <array>
#include <cstdint>
#include <vector>

struct MachineSnapshot {
    int programCounter{};
    std::uint16_t instructionRegister{};
    std::array<std::uint8_t, 16> registers{};
    std::array<std::uint8_t, 256> memory{};
    std::vector<std::uint8_t> screenOutput;
    bool halted{false};
};
#endif
