#include "ProgramLoader.h"
#include <fstream>
#include <sstream>
#include <cctype>
bool ProgramLoader::load(const std::string& path, std::vector<unsigned char>& bytes,
                         std::string& error, int startAddress) const {
    if (startAddress < 0 || startAddress >= 0xFF || (startAddress % 2) != 0) {
        error = "Start address must be even and between 00 and FE";
        return false;
    }
    std::ifstream in(path);
    if (!in) { error = "Cannot open file: " + path; return false; }
    std::vector<unsigned char> temp;
    std::string line;
    int lineNo = 0;
    while (std::getline(in, line)) {
        ++lineNo;
        auto comment = line.find(';');
        if (comment != std::string::npos) line.erase(comment);
        std::istringstream stream(line);
        std::string token;
        while (stream >> token) {
            for (char c : token) {
                if (!std::isxdigit(static_cast<unsigned char>(c))) {
                    error = "Invalid hexadecimal token at line " + std::to_string(lineNo);
                    return false;
                }
            }
            if (token.size() == 4) {
                for (int i = 0; i < 4; i += 2)
                    temp.push_back(static_cast<unsigned char>(std::stoul(token.substr(i, 2), nullptr, 16)));
            } else if (token.size() == 2) {
                temp.push_back(static_cast<unsigned char>(std::stoul(token, nullptr, 16)));
            } else {
                error = "Expected a 2-digit byte or 4-digit instruction at line " + std::to_string(lineNo);
                return false;
            }
            if (temp.size() > static_cast<std::size_t>(0xFF - startAddress)) {
                error = "Program does not fit before reserved screen address FF";
                return false;
            }
        }
    }
    if (temp.empty()) { error = "Program file is empty"; return false; }
    if ((temp.size() % 2) != 0) { error = "Program must contain complete 2-byte instructions"; return false; }
    bytes = std::move(temp);
    return true;
}
