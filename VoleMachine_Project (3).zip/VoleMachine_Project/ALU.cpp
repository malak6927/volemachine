#include "ALU.h"
#include <cmath>
#include <limits>
#include <stdexcept>

std::uint8_t ALU::addInteger(std::uint8_t a, std::uint8_t b) {
    return static_cast<std::uint8_t>(static_cast<unsigned int>(a) + b);
}

// Vole 8-bit floating-point format used here:
// 1 sign bit, 3-bit exponent biased by 4, and 4-bit normalized mantissa.
// The mantissa represents a binary fraction in the range [0.5, 0.9375].
double ALU::decodeFloat(std::uint8_t value) {
    if (value == 0) return 0.0;
    const int sign = (value & 0x80) ? -1 : 1;
    const int exponent = ((value >> 4) & 0x07) - 4;
    const int mantissa = value & 0x0F;
    if (mantissa == 0) return 0.0;
    return sign * (static_cast<double>(mantissa) / 16.0) * std::pow(2.0, exponent);
}

std::uint8_t ALU::encodeFloat(double value) {
    if (std::abs(value) < 1e-12) return 0;
    double bestError = std::numeric_limits<double>::max();
    std::uint8_t best = 0;
    bool found = false;
    for (int candidate = 0; candidate < 256; ++candidate) {
        const auto encoded = static_cast<std::uint8_t>(candidate);
        if ((encoded & 0x0F) == 0) continue;
        const double decoded = decodeFloat(encoded);
        const double error = std::abs(decoded - value);
        if (error < bestError) {
            bestError = error;
            best = encoded;
            found = true;
        }
    }
    if (!found) throw std::runtime_error("Cannot encode floating-point result");
    const double maxPositive = decodeFloat(0x7F);
    const double maxNegative = decodeFloat(0xFF);
    if (value > maxPositive || value < maxNegative)
        throw std::overflow_error("8-bit floating-point overflow");
    return best;
}

std::uint8_t ALU::addFloatingPoint(std::uint8_t a, std::uint8_t b) {
    return encodeFloat(decodeFloat(a) + decodeFloat(b));
}
std::uint8_t ALU::bitwiseOr(std::uint8_t a, std::uint8_t b) {
    return static_cast<std::uint8_t>(a | b);
}
std::uint8_t ALU::bitwiseAnd(std::uint8_t a, std::uint8_t b) {
    return static_cast<std::uint8_t>(a & b);
}
std::uint8_t ALU::bitwiseXor(std::uint8_t a, std::uint8_t b) {
    return static_cast<std::uint8_t>(a ^ b);
}
std::uint8_t ALU::rotateRight(std::uint8_t value, unsigned int count) {
    count %= 8;
    if (count == 0) return value;
    return static_cast<std::uint8_t>((value >> count) | (value << (8 - count)));
}
