
VOLE MACHINE SIMULATOR - GUI VERSION (C++ / Qt Widgets)

WHAT'S INCLUDED
- The original Vole Machine engine is preserved.
- A desktop GUI built with C++ and Qt Widgets.
- Load a hexadecimal program (.txt / .hex).
- Execute one instruction at a time (Step).
- Execute until HALT (Run), with a 10,000-instruction safety limit.
- Reset and reload the currently selected program.
- Live display of PC, IR, all 16 registers, all 256 memory bytes,
  screen output (memory-mapped address FF), and execution log.

REQUIREMENTS
- C++17 compiler (MinGW on Windows is suitable).
- CMake 3.16+.
- Qt 5 or Qt 6, Widgets module.

BUILD WITH Qt Creator
1. Install Qt (select a MinGW kit if using MinGW).
2. Open this folder's CMakeLists.txt in Qt Creator.
3. Select a configured Desktop Qt kit.
4. Configure, Build, then Run.

BUILD FROM A TERMINAL
From this folder, run:
  cmake -S . -B build
  cmake --build build --config Release

If CMake cannot find Qt, add Qt's CMake directory to CMAKE_PREFIX_PATH.
Example (adjust to your installed Qt version and compiler):
  cmake -S . -B build -DCMAKE_PREFIX_PATH="C:/Qt/6.x.x/mingw_64"

NOTES
- The GUI loads programs using the same ProgramLoader validation as the
  original project.
- Program files are expected to contain 2-digit bytes or 4-digit
  instructions in hexadecimal, with optional ';' comments.
- The GUI loads programs at address 00.
- Existing command-line main.cpp is retained. The GUI uses gui_main.cpp.
- Build with CMakeLists.txt to produce VoleMachineGUI.
