#ifndef REGISTERFILE_H
#define REGISTERFILE_H
#include <array>
#include <cstdint>
class RegisterFile {
public:
    RegisterFile();
    void reset();
    unsigned char read(int index) const;
    void write(int index, unsigned char value);
    const std::array<unsigned char, 16>& snapshot() const;
private:
    std::array<unsigned char, 16> registers{};
};
#endif
