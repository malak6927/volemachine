#include "CPU.h"
#include "ALU.h"
#include <stdexcept>
#include <string>

CPU::CPU() { reset(); }
void CPU::reset(int startAddress) { pc = startAddress; ir = 0; halted = false; }
bool CPU::isHalted() const { return halted; }
int CPU::getProgramCounter() const { return pc; }
std::uint16_t CPU::getInstructionRegister() const { return ir; }

StepResult CPU::step(Memory& memory, RegisterFile& registers, Display& display) {
    if (halted) return {true, true, "Machine is already halted"};
    if (pc < 0 || pc + 1 >= Memory::SIZE)
        return {false, false, "Program counter is outside valid instruction memory"};

    const auto first = memory.read(pc++);
    const auto second = memory.read(pc++);
    ir = static_cast<std::uint16_t>((first << 8) | second);
    const Instruction instruction = Instruction::decode(first, second);

    try {
        switch (instruction.opcode) {
            case 0x1: // Rx = memory[AA]
                registers.write(instruction.x, memory.read(instruction.operand));
                break;
            case 0x2: // Rx = immediate NN
                registers.write(instruction.x, instruction.operand);
                break;
            case 0x3: { // memory[AA] = Rx; FF is mapped to the screen
                const auto value = registers.read(instruction.x);
                memory.write(instruction.operand, value);
                if (instruction.operand == 0xFF) display.appendScreen(value);
                break;
            }
            case 0x4: // Rz = Ry
                registers.write(instruction.z, registers.read(instruction.y));
                break;
            case 0x5: // Rx = Ry + Rz (integer)
                registers.write(instruction.x, ALU::addInteger(
                    registers.read(instruction.y), registers.read(instruction.z)));
                break;
            case 0x6: // Rx = Ry + Rz (8-bit floating point)
                registers.write(instruction.x, ALU::addFloatingPoint(
                    registers.read(instruction.y), registers.read(instruction.z)));
                break;
            case 0x7: // OR
                registers.write(instruction.x, ALU::bitwiseOr(
                    registers.read(instruction.y), registers.read(instruction.z)));
                break;
            case 0x8: // AND
                registers.write(instruction.x, ALU::bitwiseAnd(
                    registers.read(instruction.y), registers.read(instruction.z)));
                break;
            case 0x9: // XOR
                registers.write(instruction.x, ALU::bitwiseXor(
                    registers.read(instruction.y), registers.read(instruction.z)));
                break;
            case 0xA: // rotate Rx right by NN bits
                registers.write(instruction.x, ALU::rotateRight(
                    registers.read(instruction.x), instruction.operand));
                break;
            case 0xB: // if Rx == R0, jump to AA
                if (registers.read(instruction.x) == registers.read(0))
                    pc = instruction.operand;
                break;
            case 0xC:
                halted = true;
                return {true, true, "HALT instruction executed"};
            default:
                return {false, false, "Unknown opcode: " + std::to_string(instruction.opcode)};
        }
    } catch (const std::exception& error) {
        return {false, false, error.what()};
    }
    return {true, false, "Instruction executed"};
}

void CPU::execute(Memory& memory, RegisterFile& registers, Display& display) {
    int safety = 0;
    while (!halted && safety++ < 10000) {
        const StepResult result = step(memory, registers, display);
        if (!result.success) throw std::runtime_error(result.message);
    }
    if (!halted) throw std::runtime_error("Execution limit reached (possible infinite loop)");
}
