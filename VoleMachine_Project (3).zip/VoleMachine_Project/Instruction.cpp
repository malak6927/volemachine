#include "Instruction.h"

Instruction Instruction::decode(std::uint8_t first, std::uint8_t second) {
    Instruction instruction;
    instruction.firstByte = first;
    instruction.secondByte = second;
    instruction.opcode = static_cast<std::uint8_t>((first >> 4) & 0x0F);
    instruction.x = static_cast<std::uint8_t>(first & 0x0F);
    instruction.y = static_cast<std::uint8_t>((second >> 4) & 0x0F);
    instruction.z = static_cast<std::uint8_t>(second & 0x0F);
    instruction.operand = second;
    return instruction;
}
