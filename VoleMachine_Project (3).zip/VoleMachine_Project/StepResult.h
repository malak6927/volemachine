#ifndef STEPRESULT_H
#define STEPRESULT_H
#include <string>

struct StepResult {
    bool success{true};
    bool halted{false};
    std::string message;
};
#endif
