#ifndef MEMORY_H
#define MEMORY_H
#include <array>
#include <string>
#include <array>
class Memory {
public:
    static constexpr int SIZE = 256;
    Memory();
    void reset();
    unsigned char read(int address) const;
    void write(int address, unsigned char value);
    bool load(const std::string& path);
    const std::array<unsigned char, SIZE>& snapshot() const;
private:
    std::array<unsigned char, SIZE> cells{};
};
#endif
