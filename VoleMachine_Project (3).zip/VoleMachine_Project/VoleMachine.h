#ifndef VOLEMACHINE_H
#define VOLEMACHINE_H
#include "Memory.h"
#include "RegisterFile.h"
#include "Display.h"
#include "CPU.h"
#include "MachineSnapshot.h"
#include <string>
class VoleMachine {
public:
    bool loadProgram(const std::string& path, std::string& error, int startAddress = 0);
    void run();
    StepResult step();
    void reset();
    void showScreen() const;
    MachineSnapshot snapshot() const;
private:
    Memory memory;
    RegisterFile registers;
    Display display;
    CPU cpu;
};
#endif
