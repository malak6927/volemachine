#include "Display.h"
#include <iostream>
#include <iomanip>
void Display::appendScreen(unsigned char value) { screen.push_back(value); }
void Display::clearScreen() { screen.clear(); }
void Display::show() const {
    std::cout << "Screen Output:\n";
    for (unsigned char value : screen)
        std::cout << std::uppercase << std::hex << std::setw(2) << std::setfill('0')
                  << static_cast<int>(value) << '\n';
    std::cout << std::dec;
}
const std::vector<unsigned char>& Display::values() const { return screen; }
