#include "Memory.h"
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdexcept>
Memory::Memory() { reset(); }
void Memory::reset() { cells.fill(0); }
unsigned char Memory::read(int address) const {
    if (address < 0 || address >= SIZE) throw std::out_of_range("Memory address out of range");
    return cells[static_cast<std::size_t>(address)];
}
void Memory::write(int address, unsigned char value) {
    if (address < 0 || address >= SIZE) throw std::out_of_range("Memory address out of range");
    cells[static_cast<std::size_t>(address)] = value;
}
bool Memory::load(const std::string& path) {
    std::ifstream in(path);
    if (!in) return false;
    reset();
    std::string token;
    int address = 0;
    while (in >> token) {
        if (!token.empty() && token[0] == ';') {
            std::string rest;
            std::getline(in, rest);
            continue;
        }
        if (token.size() != 2) return false;
        try {
            unsigned long value = std::stoul(token, nullptr, 16);
            if (address >= SIZE) return false;
            write(address++, static_cast<unsigned char>(value));
        } catch (...) { return false; }
    }
    return true;
}

const std::array<unsigned char, Memory::SIZE>& Memory::snapshot() const { return cells; }
