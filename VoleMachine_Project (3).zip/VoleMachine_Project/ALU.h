#ifndef ALU_H
#define ALU_H
#include <cstdint>

class ALU {
public:
    static std::uint8_t addInteger(std::uint8_t a, std::uint8_t b);
    static std::uint8_t addFloatingPoint(std::uint8_t a, std::uint8_t b);
    static std::uint8_t bitwiseOr(std::uint8_t a, std::uint8_t b);
    static std::uint8_t bitwiseAnd(std::uint8_t a, std::uint8_t b);
    static std::uint8_t bitwiseXor(std::uint8_t a, std::uint8_t b);
    static std::uint8_t rotateRight(std::uint8_t value, unsigned int count);
private:
    static double decodeFloat(std::uint8_t value);
    static std::uint8_t encodeFloat(double value);
};
#endif
