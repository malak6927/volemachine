#ifndef INSTRUCTION_H
#define INSTRUCTION_H
#include <cstdint>

struct Instruction {
    std::uint8_t opcode{};
    std::uint8_t x{};
    std::uint8_t y{};
    std::uint8_t z{};
    std::uint8_t operand{};
    std::uint8_t firstByte{};
    std::uint8_t secondByte{};

    static Instruction decode(std::uint8_t first, std::uint8_t second);
};
#endif
