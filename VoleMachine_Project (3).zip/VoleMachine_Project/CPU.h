#ifndef CPU_H
#define CPU_H
#include "Memory.h"
#include "RegisterFile.h"
#include "Display.h"
#include "Instruction.h"
#include "StepResult.h"
#include <cstdint>

class CPU {
public:
    CPU();
    void reset(int startAddress = 0);
    StepResult step(Memory& memory, RegisterFile& registers, Display& display);
    void execute(Memory& memory, RegisterFile& registers, Display& display);
    bool isHalted() const;
    int getProgramCounter() const;
    std::uint16_t getInstructionRegister() const;
private:
    int pc;
    std::uint16_t ir;
    bool halted;
};
#endif
