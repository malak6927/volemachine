#include "RegisterFile.h"
#include <stdexcept>
RegisterFile::RegisterFile() { reset(); }
void RegisterFile::reset() { registers.fill(0); }
unsigned char RegisterFile::read(int index) const {
    if (index < 0 || index >= 16) throw std::out_of_range("Register index out of range");
    return registers[static_cast<std::size_t>(index)];
}
void RegisterFile::write(int index, unsigned char value) {
    if (index < 0 || index >= 16) throw std::out_of_range("Register index out of range");
    registers[static_cast<std::size_t>(index)] = value;
}

const std::array<unsigned char, 16>& RegisterFile::snapshot() const { return registers; }
