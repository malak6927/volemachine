
#include "MainWindow.h"

#include <QFileDialog>
#include <QHeaderView>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QTableWidget>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QSplitter>
#include <QStatusBar>
#include <QFileInfo>
#include <QScrollBar>
#include <QFontDatabase>
#include <QApplication>
#include <QWidget>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    buildUi();
    refreshUi("Open a .txt program containing hexadecimal instructions to begin.");
    resize(1180, 780);
}

void MainWindow::buildUi() {
    setWindowTitle("Vole Machine Simulator");
    setStyleSheet(R"(
        QMainWindow, QWidget { background: #101827; color: #e5edf7; font-family: Segoe UI; font-size: 10pt; }
        QGroupBox { border: 1px solid #2d3b50; border-radius: 9px; margin-top: 12px; padding: 12px 8px 8px 8px; font-weight: 600; color: #9fc5ff; }
        QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 5px; }
        QPushButton { background: #243650; border: 1px solid #385273; border-radius: 7px; padding: 9px 17px; font-weight: 600; }
        QPushButton:hover { background: #304b70; }
        QPushButton:disabled { color: #718096; background: #1a2636; }
        QPushButton#primary { background: #2563eb; border-color: #3b82f6; color: white; }
        QPushButton#primary:hover { background: #1d4ed8; }
        QLabel#title { font-size: 20pt; font-weight: 700; color: #f8fafc; }
        QLabel#muted { color: #91a4bd; }
        QLabel#metric { background: #1a2940; border: 1px solid #2d4260; border-radius: 7px; padding: 9px; font-size: 12pt; font-weight: 700; }
        QTableWidget { background: #131f30; alternate-background-color: #18263a; gridline-color: #2b3b52; border: 1px solid #2d3b50; border-radius: 6px; selection-background-color: #254b7d; }
        QHeaderView::section { background: #20314a; color: #b9d4f5; padding: 6px; border: none; font-weight: 700; }
        QTextEdit { background: #0b1220; border: 1px solid #2d3b50; border-radius: 6px; padding: 8px; color: #c8d8ec; }
    )");

    auto *central = new QWidget(this);
    auto *outer = new QVBoxLayout(central);
    outer->setContentsMargins(18, 16, 18, 16);
    outer->setSpacing(12);

    auto *heading = new QHBoxLayout;
    auto *title = new QLabel("VOLE MACHINE");
    title->setObjectName("title");
    auto *subtitle = new QLabel("8-bit computer architecture simulator");
    subtitle->setObjectName("muted");
    auto *titleCol = new QVBoxLayout;
    titleCol->addWidget(title);
    titleCol->addWidget(subtitle);
    heading->addLayout(titleCol);
    heading->addStretch();
    fileLabel = new QLabel("No program loaded");
    fileLabel->setObjectName("muted");
    fileLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    heading->addWidget(fileLabel, 0, Qt::AlignVCenter);
    outer->addLayout(heading);

    auto *controls = new QHBoxLayout;
    auto *loadButton = new QPushButton("Load Program");
    loadButton->setObjectName("primary");
    stepButton = new QPushButton("Step  ▶");
    runButton = new QPushButton("Run  ▶▶");
    resetButton = new QPushButton("Reset  ↺");
    controls->addWidget(loadButton);
    controls->addWidget(stepButton);
    controls->addWidget(runButton);
    controls->addWidget(resetButton);
    controls->addStretch();
    statusLabel = new QLabel("READY");
    statusLabel->setObjectName("metric");
    controls->addWidget(statusLabel);
    outer->addLayout(controls);

    auto *metrics = new QHBoxLayout;
    pcLabel = new QLabel("PC: 0x00");
    irLabel = new QLabel("IR: 0x0000");
    pcLabel->setObjectName("metric");
    irLabel->setObjectName("metric");
    metrics->addWidget(pcLabel);
    metrics->addWidget(irLabel);
    metrics->addStretch();
    outer->addLayout(metrics);

    auto *topSplit = new QSplitter(Qt::Horizontal);
    auto *regBox = new QGroupBox("CPU REGISTERS  ·  R0–R15");
    auto *regLayout = new QVBoxLayout(regBox);
    registerTable = new QTableWidget(16, 3);
    registerTable->setHorizontalHeaderLabels({"Register", "Hex", "Decimal"});
    registerTable->verticalHeader()->setVisible(false);
    registerTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    registerTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    registerTable->setSelectionMode(QAbstractItemView::NoSelection);
    registerTable->setAlternatingRowColors(true);
    registerTable->verticalHeader()->setDefaultSectionSize(25);
    regLayout->addWidget(registerTable);
    topSplit->addWidget(regBox);

    auto *memBox = new QGroupBox("MEMORY  ·  256 BYTES");
    auto *memLayout = new QVBoxLayout(memBox);
    memoryTable = new QTableWidget(16, 17);
    QStringList headers{"Addr"};
    for (int i = 0; i < 16; ++i) headers << QString("%1").arg(i, 1, 16).toUpper();
    memoryTable->setHorizontalHeaderLabels(headers);
    memoryTable->verticalHeader()->setVisible(false);
    memoryTable->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    memoryTable->horizontalHeader()->setStretchLastSection(true);
    memoryTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    memoryTable->setSelectionMode(QAbstractItemView::NoSelection);
    memoryTable->setAlternatingRowColors(true);
    memoryTable->verticalHeader()->setDefaultSectionSize(25);
    memLayout->addWidget(memoryTable);
    topSplit->addWidget(memBox);
    topSplit->setStretchFactor(0, 1);
    topSplit->setStretchFactor(1, 3);
    outer->addWidget(topSplit, 5);

    auto *bottomSplit = new QSplitter(Qt::Horizontal);
    auto *screenBox = new QGroupBox("SCREEN OUTPUT  ·  MEMORY ADDRESS FF");
    auto *screenLayout = new QVBoxLayout(screenBox);
    screenOutput = new QTextEdit;
    screenOutput->setReadOnly(true);
    screenOutput->setPlaceholderText("Output written to memory address FF will appear here...");
    screenLayout->addWidget(screenOutput);
    bottomSplit->addWidget(screenBox);

    auto *logBox = new QGroupBox("EXECUTION LOG");
    auto *logLayout = new QVBoxLayout(logBox);
    logOutput = new QTextEdit;
    logOutput->setReadOnly(true);
    logOutput->setPlaceholderText("Instruction execution messages...");
    logLayout->addWidget(logOutput);
    bottomSplit->addWidget(logBox);
    outer->addWidget(bottomSplit, 2);

    setCentralWidget(central);
    statusBar()->showMessage("Vole Machine Simulator · Ready");

    connect(loadButton, &QPushButton::clicked, this, &MainWindow::loadProgram);
    connect(stepButton, &QPushButton::clicked, this, &MainWindow::stepProgram);
    connect(runButton, &QPushButton::clicked, this, &MainWindow::runProgram);
    connect(resetButton, &QPushButton::clicked, this, &MainWindow::resetProgram);
}

QString MainWindow::hexByte(unsigned char value) const {
    return QString("%1").arg(static_cast<unsigned int>(value), 2, 16, QLatin1Char('0')).toUpper();
}

void MainWindow::loadProgram() {
    const QString path = QFileDialog::getOpenFileName(this, "Open Vole Machine Program", QString(),
                                                       "Hex programs (*.txt *.hex);;All files (*)");
    if (path.isEmpty()) return;
    std::string error;
    if (!machine.loadProgram(path.toStdString(), error, 0)) {
        QMessageBox::critical(this, "Program Load Error", QString::fromStdString(error));
        return;
    }
    loadedPath = path;
    programLoaded = true;
    fileLabel->setText(QFileInfo(path).fileName());
    logOutput->clear();
    appendLog("Loaded: " + path);
    appendLog("Program loaded into memory starting at 0x00.");
    refreshUi("Program loaded successfully.");
}

void MainWindow::stepProgram() {
    if (!programLoaded) {
        QMessageBox::information(this, "No Program", "Load a program first.");
        return;
    }
    if (machine.snapshot().halted) return;
    const int before = machine.snapshot().programCounter;
    const StepResult result = machine.step();
    appendLog(QString("PC %1  |  %2").arg(hexByte(static_cast<unsigned char>(before)),
                                         QString::fromStdString(result.message)));
    if (!result.success) {
        statusLabel->setText("ERROR");
        QMessageBox::critical(this, "Execution Error", QString::fromStdString(result.message));
    } else if (result.halted) {
        statusLabel->setText("HALTED");
        appendLog("CPU halted.");
    }
    refreshUi(QString::fromStdString(result.message));
}

void MainWindow::runProgram() {
    if (!programLoaded) {
        QMessageBox::information(this, "No Program", "Load a program first.");
        return;
    }
    int count = 0;
    while (!machine.snapshot().halted && count < 10000) {
        const int before = machine.snapshot().programCounter;
        const StepResult result = machine.step();
        ++count;
        appendLog(QString("PC %1  |  %2").arg(hexByte(static_cast<unsigned char>(before)),
                                             QString::fromStdString(result.message)));
        if (!result.success) {
            statusLabel->setText("ERROR");
            QMessageBox::critical(this, "Execution Error", QString::fromStdString(result.message));
            refreshUi(QString::fromStdString(result.message));
            return;
        }
        if (result.halted) break;
    }
    if (!machine.snapshot().halted) {
        statusLabel->setText("LIMIT");
        QMessageBox::warning(this, "Execution Limit", "Stopped after 10,000 instructions (possible infinite loop).");
    } else {
        statusLabel->setText("HALTED");
        appendLog(QString("Execution finished. %1 instruction(s) processed.").arg(count));
    }
    refreshUi("Execution finished.");
}

void MainWindow::resetProgram() {
    if (!programLoaded) return;
    std::string error;
    if (!machine.loadProgram(loadedPath.toStdString(), error, startAddress)) {
        QMessageBox::critical(this, "Reset Error", QString::fromStdString(error));
        return;
    }
    logOutput->clear();
    appendLog("Machine reset. Program reloaded from the beginning.");
    refreshUi("Machine reset.");
}

void MainWindow::appendLog(const QString &message) {
    logOutput->append(message.toHtmlEscaped());
    logOutput->verticalScrollBar()->setValue(logOutput->verticalScrollBar()->maximum());
}

void MainWindow::refreshUi(const QString &message) {
    const MachineSnapshot state = machine.snapshot();
    pcLabel->setText(QString("PC: 0x%1").arg(hexByte(static_cast<unsigned char>(state.programCounter))));
    irLabel->setText(QString("IR: 0x%1").arg(QString("%1").arg(state.instructionRegister, 4, 16, QLatin1Char('0')).toUpper()));
    if (state.halted) statusLabel->setText("HALTED");
    else if (programLoaded) statusLabel->setText("RUNNING / READY");
    else statusLabel->setText("READY");

    for (int i = 0; i < 16; ++i) {
        auto put = [this, i](int col, const QString &value) {
            auto *item = new QTableWidgetItem(value);
            item->setTextAlignment(Qt::AlignCenter);
            registerTable->setItem(i, col, item);
        };
        put(0, QString("R%1").arg(i, 0, 16).toUpper());
        put(1, hexByte(state.registers[static_cast<std::size_t>(i)]));
        put(2, QString::number(state.registers[static_cast<std::size_t>(i)]));
    }

    for (int row = 0; row < 16; ++row) {
        auto *address = new QTableWidgetItem(hexByte(static_cast<unsigned char>(row * 16)));
        address->setTextAlignment(Qt::AlignCenter);
        memoryTable->setItem(row, 0, address);
        for (int col = 0; col < 16; ++col) {
            const auto value = state.memory[static_cast<std::size_t>(row * 16 + col)];
            auto *item = new QTableWidgetItem(hexByte(value));
            item->setTextAlignment(Qt::AlignCenter);
            memoryTable->setItem(row, col + 1, item);
            if (row * 16 + col == 0xFF) item->setToolTip("Screen output mapped address");
        }
    }

    QString output;
    for (std::size_t i = 0; i < state.screenOutput.size(); ++i) {
        if (i) output += "\n";
        output += hexByte(state.screenOutput[i]);
    }
    screenOutput->setPlainText(output);
    if (!message.isEmpty()) statusBar()->showMessage(message, 5000);
    stepButton->setEnabled(programLoaded && !state.halted);
    runButton->setEnabled(programLoaded && !state.halted);
    resetButton->setEnabled(programLoaded);
}
