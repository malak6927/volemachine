VOLE MACHINE SIMULATOR - CS213 IMPLEMENTATION

Source files:
- VoleMachine.h/.cpp: top-level machine and MachineSnapshot creation
- CPU.h/.cpp: fetch/decode/execute cycle and StepResult
- Instruction.h/.cpp: instruction decoding
- ALU.h/.cpp: arithmetic and bitwise operations
- Memory.h/.cpp: 256-byte memory
- RegisterFile.h/.cpp: sixteen 8-bit registers
- Display.h/.cpp: screen output device (memory address FF)
- ProgramLoader.h/.cpp: hexadecimal program file loader and validation
- StepResult.h, MachineSnapshot.h: execution result and machine-state snapshot
- main.cpp: console interface

Build (g++):
g++ -std=c++17 -Wall -Wextra Memory.cpp RegisterFile.cpp ProgramLoader.cpp Display.cpp Instruction.cpp ALU.cpp CPU.cpp VoleMachine.cpp main.cpp -o VoleMachine.exe

Run (PowerShell):
.\VoleMachine.exe
Then enter a program filename, e.g. Program2_OR.txt

Implemented instruction set:
1xAA: Rx = memory[AA]
2xNN: Rx = NN
3xAA: memory[AA] = Rx; AA=FF also appends Rx to screen output
4xYZ: Rz = Ry
5xYZ: Rx = Ry + Rz (unsigned 8-bit integer; overflow wraps)
6xYZ: Rx = Ry + Rz (8-bit floating-point; see format note below)
7xYZ: Rx = Ry OR Rz
8xYZ: Rx = Ry AND Rz
9xYZ: Rx = Ry XOR Rz
AxNN: rotate Rx right by NN bits (NN modulo 8)
BxAA: if Rx == R0, jump to AA
C000: halt

Floating-point format assumption for opcode 6:
1 sign bit, 3-bit exponent biased by 4, and 4-bit normalized mantissa.
The assignment handout must be checked to confirm this exact representation before final submission.

Sample programs:
- Program1_Report.txt -> 0C
- Program2_OR.txt -> 0F
- Program2_Bus_Integrity.txt -> 05, FF, 0F
