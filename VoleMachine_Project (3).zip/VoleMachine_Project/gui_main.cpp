
#include "MainWindow.h"
#include <QApplication>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    QApplication::setApplicationName("Vole Machine Simulator");
    MainWindow window;
    window.show();
    return app.exec();
}
