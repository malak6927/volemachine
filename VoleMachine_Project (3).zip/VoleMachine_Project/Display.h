#ifndef DISPLAY_H
#define DISPLAY_H
#include <vector>
#include <string>
class Display {
public:
    void appendScreen(unsigned char value);
    void clearScreen();
    void show() const;
    const std::vector<unsigned char>& values() const;
private:
    std::vector<unsigned char> screen;
};
#endif
