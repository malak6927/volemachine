#include "VoleMachine.h"
#include <iostream>
#include <string>
int main() {
    VoleMachine machine;
    std::string path, error;
    std::cout << "Vole Machine\n";
    std::cout << "Enter program file name: ";
    std::getline(std::cin, path);
    if (path.empty()) { std::cerr << "No file name entered.\n"; return 1; }
    if (!machine.loadProgram(path, error)) {
        std::cerr << "Load Error: " << error << '\n';
        return 1;
    }
    std::cout << "Program Loaded Successfully!\n";
    try {
        machine.run();
        std::cout << "Program Executed.\n";
        machine.showScreen();
    } catch (const std::exception& e) {
        std::cerr << "Execution Error: " << e.what() << '\n';
        return 1;
    }
    return 0;
}
