#ifndef PROGRAMLOADER_H
#define PROGRAMLOADER_H
#include <vector>
#include <string>
class ProgramLoader {
public:
    bool load(const std::string& path, std::vector<unsigned char>& bytes,
              std::string& error, int startAddress = 0) const;
};
#endif
